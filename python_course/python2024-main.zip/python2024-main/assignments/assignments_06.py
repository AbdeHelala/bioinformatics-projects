
import numpy as np


def possible_sequences(seqLength, alphabetSize):
    pass


def sequence_complexity(sequence, alphabetSize):
    pass


def align(s, q, score):
    pass


def convert_read(fastq, maxError):
    pass
