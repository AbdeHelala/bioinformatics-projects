import numpy as np
from numba import njit

def move_mean_python(lst, window):
    pass

def move_mean_numba(array, window_size):
    pass

def largest_k(n):
    pass