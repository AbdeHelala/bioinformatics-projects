
# Task 1
def process_list(mylist):
	pass

# Task 2
def DNA_complement(seq):
    pass
    
# Task 3
def list_kmers(seq, k):
    pass

def number_of_unique(seq, k):
    pass

# Task 4

def kmer_code(kmer):
    pass

def kmer_decode(code, k):
    pass